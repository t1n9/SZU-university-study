package sixth;

public interface Human {
	//���󷽷�
	public abstract double sayHi();
}