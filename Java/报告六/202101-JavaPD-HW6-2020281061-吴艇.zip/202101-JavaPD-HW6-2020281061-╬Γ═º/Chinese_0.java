package sixth;

public class Chinese_0 extends Human_0{
	Chinese_0(String _name) {
		super(_name);
	}
	public double sayHi() {
		System.out.println("���!");
		return 0;
	}
}
