package sixth;

public class English_0 extends Human_0{
	English_0(String _name) {
		super(_name);
	}
	public double sayHi() {
		System.out.println("Hello!");
		return 0;
	}
}
