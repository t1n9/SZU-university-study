package sixth;

public class Student {
	public String name;
	public Student(String _name){
		name = _name;
	}
	public String studentname() {
		return name;
	}
}
