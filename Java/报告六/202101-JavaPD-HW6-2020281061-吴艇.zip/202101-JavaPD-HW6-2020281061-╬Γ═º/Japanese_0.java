package sixth;

public class Japanese_0 extends Human_0{
	Japanese_0(String _name) {
		super(_name);
	}
	public double sayHi() {
		System.out.println("kon ni chi wa!");
		return 0;
	}
}
