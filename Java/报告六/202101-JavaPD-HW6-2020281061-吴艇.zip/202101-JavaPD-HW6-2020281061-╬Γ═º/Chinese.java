package sixth;

public class Chinese implements Human{
	String name;
	Chinese(String _name){
		name = _name;
	}
	public double sayHi() {
		System.out.println("���!");
		return 0;
	}
}
