package sixth;

public class Dish {
	String name;
	double price;
	Dish(String _name,double _price){
		name = _name;
		price = _price;
	}
}
