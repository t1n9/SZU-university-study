package sixth;

import java.util.*;
public class Nation_2 {

	public String name;
	public int GDP2020,COVID19;
	Nation_2(String name,int GDP2020,int COVID19){
		this.name = name;
		this.GDP2020 = GDP2020;
		this.COVID19 = COVID19;
	}
	
}
