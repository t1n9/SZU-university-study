package eighth;

class Bank implements Runnable{
	int money = 300;
	@Override
	public void run() {
		//�ô�ȡ������ִ��ʮ��
		int i=10;
		while(i--!=0) {
			saveOrTake(30);
		}
	}
	public synchronized void saveOrTake(int number) {
		if(Thread.currentThread().getName().equals("save")) {
			money += number;
			System.out.println("�����:"+money);
		}else if(Thread.currentThread().getName().equals("take")) {
			money-=number;
			System.out.println("ȡ����:"+money);
		}
	}
	
}

public class Example_3 {
	public static void main(String[] args) {
		Bank bank = new Bank();
		Thread save = new Thread(bank);
		Thread take = new Thread(bank);
		save.setName("save");
		take.setName("take");
		save.start();
		take.start();
	}
}
