package eighth;

class Bridge implements Runnable{
	static String west_[] = {"W1","W2","W3","W4","W5","W6","W7","W8","W9","W10","W11","W12","W13","W14","W15","W16","W17","W18","W19","W20"};
	static String east_[] = {"E1","E2","E3","E4","E5","E6","E7","E8","E9","E10","E11","E12","E13","E14","E15","E16","E17","E18","E19","E20"};
	int e,w;
	@Override
	public void run() {
		e = 0;
		w = 0;
		while(e<20 || w<20) {
			pass();
		}
	}
	public synchronized void pass() {
		if(Thread.currentThread().getName().equals("east")) {
			if(e<20) {
				System.out.print(east_[e++]+";");
				
			}
		}else if(Thread.currentThread().getName().equals("west")) {
			if(w<20) {
				System.out.print(west_[w++]+";");
			}
		}
	}
}
public class Example_4 {
	public static void main(String[] args) {
		Bridge bridge = new Bridge();
		Thread east = new Thread(bridge);
		Thread west = new Thread(bridge);
		east.setName("east");
		west.setName("west");
		east.start();
		west.start();
	}
}
