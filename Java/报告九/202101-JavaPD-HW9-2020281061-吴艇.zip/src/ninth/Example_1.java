package ninth;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Example_1 {
    public static void main(String[] args) {
        Window win = new Window();
    }
}

class Window extends JFrame implements ActionListener {
	
    Box base,box1,box2,box3;
    JTextField input,output_1,output_2,output_3;
    // �ٶȷ���app_id,security_key
    final String APP_ID = "20211204001018921";
    static final String SECURITY_KEY = "XrhF2InwmbLOcr5CLiFa";

    // Ѷ�ɷ���appid,api_secret,api_keyд��WebITS����    
    
    Window() {

        // box1�����ʾ
        box1 = Box.createVerticalBox();
        box1.add(new JLabel("���������ģ�"));
        box1.add(Box.createVerticalStrut(16));
        box1.add(new JLabel("�ٶȷ�������"));
        box1.add(Box.createVerticalStrut(16));
        box1.add(new JLabel("Ѷ�ɷ�������"));
        box1.add(Box.createVerticalStrut(16));
        box1.add(new JLabel("��֮ͬ����"));
        box1.add(Box.createVerticalStrut(16));


        // box2�м����
        box2 = Box.createVerticalBox();

        // �ı������
        input = new JTextField(40);
        input.addActionListener(this);
        box2.add(input);

        box2.add(Box.createVerticalStrut(16));

        // �ٶȷ�����
        output_1 = new JTextField(40);
        output_1.setEditable(false);
        box2.add(output_1);

        box2.add(Box.createVerticalStrut(16));

        // Ѷ�ɷ�����
        output_2 = new JTextField(40);
        output_2.setEditable(false);
        box2.add(output_2);

        box2.add(Box.createVerticalStrut(16));

        // difference
        output_3 = new JTextField(40);
        output_3.setEditable(false);
        box2.add(output_3);

        box2.add(Box.createVerticalStrut(16));


        // box3���밴ť
        box3 = Box.createVerticalBox();
        JButton start = new JButton(("����"));
        start.addActionListener(this);
        box3.add(start);

        // base
        base = Box.createHorizontalBox();
        base.add(box1);
        base.add(Box.createHorizontalStrut(10));
        base.add(box2);
        base.add(Box.createHorizontalStrut(10));
        base.add(box3);

        // ---
        FlowLayout flow = new FlowLayout();
        flow.setAlignment(FlowLayout.LEFT);
        setLayout(flow);

        setTitle("Translator");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.add(base);
        validate();
        setBounds(120,125,600,200);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
	
        String query = input.getText();

        // �ٶȷ���
        TransApi Baidu_api = new TransApi(APP_ID, SECURITY_KEY);
        String Baidu_RETURN = Baidu_api.getTransResult(query, "auto", "en");
        String BaiduOutPut = query;
        // ����������ȡ����������
        Pattern p = Pattern.compile("\"(.*?)\"");
        Matcher m1 = p.matcher(Baidu_RETURN);
        while(m1.find()){
            BaiduOutPut = m1.group();
        }

        BaiduOutPut = BaiduOutPut.replaceAll("\"","");
        
        output_1.setText(BaiduOutPut);

        // Ѷ�ɷ���
        WebITS Xunfei_api = new WebITS();
        String XunfeiOutPut = query;
        
        String Xunfei_RESULT = null;
		try {
			Xunfei_RESULT = Xunfei_api.returnResult(query);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// ������ģʽƥ����ƥ����
		String[] temp = new String[16];
		int i = 0;
		Matcher m2 = p.matcher(Xunfei_RESULT);
		while(m2.find()) {
			temp[i++] = m2.group();
		}
		XunfeiOutPut = temp[9];
		XunfeiOutPut = XunfeiOutPut.replaceAll("\"","");
        output_2.setText(XunfeiOutPut);
        
        
        
        
        // ����������бȽ�
        
        // �ȸ�ʽͳһ��ȥ�����
        String compareBaidu = BaiduOutPut.replaceAll("[,.!]", "");
        String compareXunfei = XunfeiOutPut.replaceAll("[,.!]", "");
        
        // ��ÿ��������������˫���ţ������Ϳ���ʹ�����涨���pattern
        compareBaidu = compareBaidu.replaceAll(" ","\"\"");
        compareXunfei = compareXunfei.replaceAll(" ","\"\"");
        StringBuffer temp1 = new StringBuffer(compareBaidu);
        StringBuffer temp2 = new StringBuffer(compareXunfei);
        temp1.insert(0, '\"');
        temp1.insert(temp1.length(), '\"');
        temp2.insert(0, '\"');
        temp2.insert(temp2.length(), '\"');
        compareBaidu = temp1.toString();
        compareXunfei = temp2.toString();
        String []comp1 = new String[20];
        String []comp2 = new String[20];
        Matcher m3 = p.matcher(compareBaidu);
        Matcher m4 = p.matcher(compareXunfei);
        i = 0;
        while(m3.find()) {
        	comp1[i++] = m3.group();
        }
        
        i = 0;
        while(m4.find()) {
        	comp2[i++] = m4.group();
        }

        // ����
//        for(i = 0;i<20;i++) {
//        	if(comp1[i] == null)
//        		break;
//            System.out.print(comp1[i]+" ");
//        }
//        for(i = 0;i<20;i++) {
//        	if(comp2[i] == null)
//        		break;
//            System.out.print(comp2[i]+" ");
//        }
//        System.out.print(comp1[0].compareTo(comp2[0]));
//        System.out.print(comp1[0]+" ");
//        System.out.print(comp2[0]+" ");
        
        //����ͬ�ĵ��ʼ�¼����
        String []same = new String[20];
        int k = 0;
        for(i = 0;comp1[i] != null;i++) {
        	for(int j = 0;comp2[j] != null;j++) {
            	if(comp1[i].compareTo(comp2[j]) == 0) {
        			same[k++] = comp2[j];
        			break;
            	}
        	}
        }
        	
        // ����
//	    for(i = 0;i<20;i++) {
//	    	if(same[i] == null)
//	    		break;
//	        System.out.print(same[i]+" ");
//      	}
        
        String sameResult ="";
        
        for(i = 0;i<same.length;i++) {
        	if(same[i] == null)
        		break;
        	sameResult += same[i];
        	sameResult +=" ";
        }
//        System.out.println(sameResult);
        output_3.setText(sameResult);
        
    }

}


